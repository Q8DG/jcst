//
// 默认支持编码列表
//

const ENCODES = [
  'GBK',
  'UTF8',
  'BIG5',
  'GB2312',
  'Euc-KR',
  'Euc-JP',
  'Shift_JIS',
  'ISO-8859-1',
  'Windows-874',
  'Windows-1251'
];
module.exports = ENCODES;