/*
oracle
*/

module.exports = require('./default');